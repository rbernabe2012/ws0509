@extends('errors::minimal')

@section('title', __tr('Too Many Requests'))
@section('code', '429')
@section('message', __tr('Too Many Requests'))
