@extends('errors::minimal')

@section('title', __tr('Unauthorized'))
@section('code', '401')
@section('message', __tr('Unauthorized'))
