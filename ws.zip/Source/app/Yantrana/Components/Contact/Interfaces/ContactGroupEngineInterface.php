<?php
/**
* ContactGroupEngineInterface.php - Interface file
*
* This file is part of the ContactGroup component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Contact\Interfaces;

interface ContactGroupEngineInterface
{
}
