<?php

/**
 * UserRepositoryInterface.php - Interface file
 *
 * This file is part of the User component.
 *-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\User\Interfaces;

interface UserRepositoryInterface
{
}
