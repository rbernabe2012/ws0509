<?php
/**
* WhatsAppMessageLogRepositoryInterface.php - Interface file
*
* This file is part of the WhatsAppService component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\WhatsAppService\Interfaces;

interface WhatsAppMessageLogRepositoryInterface
{
}
